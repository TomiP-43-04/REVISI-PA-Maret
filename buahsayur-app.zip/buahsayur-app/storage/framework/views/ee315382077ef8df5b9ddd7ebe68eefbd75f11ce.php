
<?php $__env->startSection('container'); ?>

<!-- ======= About Section ======= -->
<section id="about" class="about">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <img src="/img/fruits.png" style="max-height: 100px;">
        <h2>Profil</h2>
        <img src="/img/vegetable.png" style="max-height: 100px;">
        <h3>Mengenai <span>Buah dan Sayur</span></h3>
        <p>Berbagai Katalog Buah dan Sayur.</p>
      </div>

      <div class="row">
          <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">

              <?php if($profile->image): ?>
                <div class="rounded shadow mb-3 bg-white rounded">
                  <img src="<?php echo e(asset('img/profile-images/' . $profile->image)); ?>" class="img-fluid" alt="">
                </div>
              <?php else: ?>
                <div class="rounded shadow mb-3 bg-white rounded">
                  <img src="<?php echo e(asset('img/profile-images/' . $image)); ?>" class="img-fluid" alt="">
                </div>
              <?php endif; ?>

            </div>
            <div class="col-lg-6 pt-4 pt-lg-0 content d-flex flex-column" data-aos="fade-up" data-aos-delay="100"> 
              <h3>Buah dan Sayur</h3>
              <p class="text-justify">
                <?php echo $profile->profil; ?>

              </p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
  </section><!-- End About Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\buahsayur-app\resources\views/home/profiles/index.blade.php ENDPATH**/ ?>