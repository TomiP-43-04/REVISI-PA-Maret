

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-md-8">
                <h2 class="mb-3"><?php echo e($post->title); ?></h2>
                <p>By. <a href="/posts?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a> in <a href="/posts?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?></a></p>
                <?php if($post->image): ?>
                <div style="max-height: 350px; overflow:hidden;">
                    <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                </div>
                <?php else: ?>
                    <img src="https://source.unsplash.com/1200x400?<?php echo e($post->category->name); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                <?php endif; ?>
                <article class="my-3">
                    <?php echo $post->body; ?>

                </article>
                <a href="/posts" class="text-decoration-none d-block mt-3">Back</a>
            </div>
        </div>
    </div>
    <article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/post.blade.php ENDPATH**/ ?>