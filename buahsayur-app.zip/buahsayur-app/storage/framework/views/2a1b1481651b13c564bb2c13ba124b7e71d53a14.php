

<?php $__env->startSection('container'); ?>
    <main id="main" data-aos="fade-up">
         <!-- ======= Breadcrumbs Section ======= -->
        <section class="breadcrumbs">
            <div class="container">
    
            <div class="d-flex justify-content-between align-items-center">
                <ol>
                <li><a href="/">Beranda</a></li>
                <li><a href="/home/catalogs">Katalog</a></li>
                <li>Rincian Katalog</li>
                </ol>
            </div>
    
            </div>
        </section><!-- Breadcrumbs Section -->

        <div class="container mt-3">
            <div class="row justify-content-center mb-5">
                <div class="col-md-8 shadow p-3 mb-5 bg-white rounded border">
                    <?php if($catalog->barang->status_musim == 1): ?>
                    <h4 style="color: orange"><?php echo e($catalog->nama_barang); ?> (Sedang Musim)</h4>
                    <?php else: ?>
                        <h4 style="color: orange"><?php echo e($catalog->nama_barang); ?></h4>
                    <?php endif; ?>
                    <h4 style="display: inline">Rp. <?= number_format($catalog->harga_barang, 0, ',', '.') ?></h4> /<?php echo e($catalog->satuan->nama_satuan); ?>

                    <p>oleh <a href="/home/catalogs?author=<?php echo e($catalog->user->username); ?>" class="text-decoration-none"><?php echo e($catalog->user->nama); ?></a> di <a href="/home/catalogs?category=<?php echo e($catalog->kategori->slug); ?>" class="text-decoration-none"><?php echo e($catalog->kategori->nama_kategori); ?></a></p>
                    <?php if($catalog->image): ?>
                        <center>
                            <img src="<?php echo e(asset('img/catalog-images/' . $catalog->image)); ?>" alt="<?php echo e($catalog->kategori->nama_kategori); ?>" class="img-fluid rounded">
                        </center>
                    <?php else: ?>
                        <center>
                            <img src="<?php echo e(asset('img/catalog-images/' . $image)); ?>" class="card-img-top rounded">
                        </center>
                    <?php endif; ?>
                    <article class="my-3">
                        <?php echo $catalog->desk_barang; ?>

                    </article>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\buahsayur-app\resources\views/home/catalogs/show.blade.php ENDPATH**/ ?>