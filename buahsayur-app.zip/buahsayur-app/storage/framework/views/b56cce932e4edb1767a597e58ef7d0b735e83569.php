

<?php $__env->startSection('container'); ?>
<div class="container mt-4">
    <div class="row mb-5">
        <div class="col-md-8 shadow p-3 mb-5 bg-white rounded border">
            <?php if($allcatalog->barang->status_musim == 1): ?>
            <h4 style="color: orange"><?php echo e($allcatalog->nama_barang); ?> (Sedang Musim)</h4>
            <?php else: ?>
                <h4 style="color: orange"><?php echo e($allcatalog->nama_barang); ?></h4>
            <?php endif; ?>
            <h4 style="display: inline">Rp. <?= number_format($allcatalog->harga_barang, 0, ',', '.') ?></h4> /<?php echo e($allcatalog->satuan->nama_satuan); ?>

            <p>oleh <a href="/home/catalogs?author=<?php echo e($allcatalog->user->username); ?>" class="text-decoration-none"><?php echo e($allcatalog->user->nama); ?></a> di <a href="/home/catalogs?category=<?php echo e($allcatalog->kategori->slug); ?>" class="text-decoration-none"><?php echo e($allcatalog->kategori->nama_kategori); ?></a></p>
            <?php if($allcatalog->image): ?>
                <center>
                    <img src="<?php echo e(asset('img/catalog-images/' . $allcatalog->image)); ?>" alt="<?php echo e($allcatalog->kategori->nama_kategori); ?>" class="img-fluid rounded">
                </center>
            <?php else: ?>
                <center>
                    <img src="<?php echo e(asset('img/catalog-images/' . $image)); ?>" class="card-img-top rounded">
                </center>
            <?php endif; ?>
            <article class="my-3">
                <?php echo $allcatalog->desk_barang; ?>

            </article>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\buahsayur-app\resources\views/dashboard/allcatalogs/show.blade.php ENDPATH**/ ?>