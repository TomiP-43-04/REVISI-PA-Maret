

<?php $__env->startSection('container'); ?> 
    <section id="portfolio" class="portfolio">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <img src="/img/fruits.png" style="max-height: 100px;">
                <h2>Katalog</h2>
                <img src="/img/vegetable.png" style="max-height: 100px;">
                <h3>Lebih Banyak <span>Katalog</span></h3>
                <p>Katalog Buah-buahan dan Sayuran.</p>
            </div>

            <div class="row">
                <div class="section-title col-lg-12 d-flex justify-content-center">
                  <ul id="portfolio-flters">
                    <li><h2><a href="/home/catalogs">Semua</h2></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><h2><a href="/home/catalogs?kategori=<?php echo e($category->slug); ?>"><?php echo e($category->nama_kategori); ?></a></h2></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>

            <div class="row justify-content-center mb-3">
                <div class="col-md-6">
                    <form action="/home/catalogs">
                        <?php if(request('kategori')): ?>
                            <input type="hidden" name="kategori" value="<?php echo e(request('kategori')); ?>">
                        <?php endif; ?>
        
                        <?php if(request('user')): ?>
                            <input type="hidden" name="user" value="<?php echo e(request('user')); ?>">
                        <?php endif; ?>
        
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Cari katalog.." name="search" value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-primary" type="submit">Cari</button>
                        </div>
                    </form>
                </div>
            </div>
        
            <?php if($catalogs->count()): ?>
                    <div class="row">
                        <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-3">
                                <div class="card h-100 shadow p-1 mb-5 bg-white rounded" data-aos="fade-up" data-aos-delay="100">
                                    <div class="position-absolute px-3 py-2 text-white rounded" style="background-color: rgba(255, 165, 0, 0.7)"><a href="/home/catalogs?kategori=<?php echo e($catalog->kategori->slug); ?>" class="text-white text-decoration-none"><?php echo e($catalog->kategori->nama_kategori); ?></a></div>
                                    <?php if($catalog->image): ?>
                                        <img src="<?php echo e(asset('img/catalog-images/' . $catalog->image)); ?>" class="img-fluid rounded" style="max-width: 100%; max-height: 220px; object-fit:cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('img/catalog-images/' . $image)); ?>" class="card-img-top rounded" style="max-width: 100%; max-height: 220px; object-fit:cover;">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <?php if($catalog->barang->status_musim == 1): ?>
                                            <h5 style="color: orange" class="card-title"><?php echo e($catalog->nama_barang); ?> (Sedang Musim)</h5>
                                        <?php else: ?>
                                            <h5 style="color: orange" class="card-title"><?php echo e($catalog->nama_barang); ?></h5>
                                        <?php endif; ?>
                                    <p>
                                        <small class="text-muted">
                                           Oleh <a href="/home/catalogs?user=<?php echo e($catalog->user->username); ?>" class="text-decoration-none"><?php echo e($catalog->user->nama); ?></a> <?php echo e($catalog->updated_at->diffForHumans()); ?>

                                        </small>
                                    </p>
                                    <?php if($catalog->barang->peminat == 1): ?>
                                        <p class="card-text"> <h4 style="display: inline">Rp. <?= number_format($catalog->harga_barang, 0, ',', '.') ?></h4> /<?php echo e($catalog->satuan->nama_satuan); ?> <span class="bi bi-hand-thumbs-up-fill                                            "></span>
                                            <br />
                                            <small class="text-muted">Harga <?php echo e($catalog->barang->persentase); ?></small>
                                        </p>
                                    <?php else: ?>
                                        <p class="card-text"> <h4 style="display: inline">Rp. <?= number_format($catalog->harga_barang, 0, ',', '.') ?></h4> /<?php echo e($catalog->satuan->nama_satuan); ?>

                                            <br />
                                            <small class="text-muted">Harga <?php echo e($catalog->barang->persentase); ?></small>
                                        </p>
                                    <?php endif; ?>
                                    <a href="/home/catalogs/<?php echo e($catalog->slug); ?>" class="text-decoration-none btn btn-primary" style="width: 100%;">Selengkapnya</a>
                                    <a href="/home/users/<?php echo e($catalog->id_user); ?>" class="text-decoration-none btn btn-success mt-1" style="width: 100%;">Informasi Toko</a>
                                    <a href="<?php echo e($catalog->user->link_toko); ?>" class="text-decoration-none btn btn-warning mt-1" style="width: 100%;">Kunjungi Marketplace</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            <?php else: ?>
                <p class="text-center fs-4">No catalog found.</p>
            <?php endif; ?>
        
            <div class="d-flex justify-content-center">
                <?php echo e($catalogs->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\buahsayur-app\resources\views/home/catalogs/index.blade.php ENDPATH**/ ?>