<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
      <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-3 mb-1 text-muted">
        <span>Dashboard</span>
      </h6>
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/catalogs*') ? 'active' : ''); ?>" href="/dashboard/catalogs">
            <span data-feather="file-text"></span>
            Katalog Saya
          </a>
        </li>
      </ul>

      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/passwords*') ? 'active' : ''); ?>" href="/dashboard/passwords">
            <span data-feather="lock"></span>
            Ganti Kata Sandi
          </a>
        </li>
      </ul>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-3 mb-1 text-muted">
          <span>Administrator</span>
        </h6>

        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/suppliers*') ? 'active' : ''); ?>" href="/dashboard/suppliers">
              <span data-feather="book-open"></span>
              Katalog Supplier
            </a>
          </li>
        </ul> 

        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/users*') ? 'active' : ''); ?>" href="/dashboard/users">
              <span data-feather="shopping-bag"></span>
              Data Toko
            </a>
          </li>
        </ul> 

        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/categories*') ? 'active' : ''); ?>" href="/dashboard/categories">
              <span data-feather="grid"></span>
              Kategori Produk
            </a>
          </li>
        </ul>

        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/units*') ? 'active' : ''); ?>" href="/dashboard/units">
              <span data-feather="database"></span>
              Satuan Produk
            </a>
          </li>
        </ul>
        
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/profiles*') ? 'active' : ''); ?>" href="/dashboard/profiles">
              <span data-feather="briefcase"></span>
              Profil Website
            </a>
          </li>
        </ul>  

        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/allcatalogs*') ? 'active' : ''); ?>" href="/dashboard/allcatalogs">
              <span data-feather="book"></span>
              Semua Katalog
            </a>
          </li>
        </ul>

      <?php endif; ?>

    </div>
  </nav><?php /**PATH E:\Project\Laravel\buahsayur-app\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>