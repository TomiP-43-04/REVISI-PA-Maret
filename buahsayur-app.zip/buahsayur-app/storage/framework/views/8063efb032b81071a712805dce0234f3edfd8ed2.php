
<?php $__env->startSection('container'); ?>
  <!-- ======= Team Section ======= -->
  <section id="team" class="team">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <img src="/img/fruits.png" style="max-height: 100px;">
        <h2>Toko Buah dan Sayur</h2>
        <img src="/img/vegetable.png" style="max-height: 100px;">
        <h3>Mengenai <span><?php echo e($users->nama); ?></span></h3>
        <p><?php echo $users->email; ?> (<?php echo $users->telp; ?>)</p>
      </div>

      <div class="row">
          <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">

            <?php if($users->image): ?>
              <div class="rounded">
                <img src="<?php echo e(asset('img/user-images/' . $users->image)); ?>" class="img-fluid" alt="">
              </div>
            <?php else: ?>
              <div class="rounded">
                <img src="<?php echo e(asset('img/user-images/' . $image)); ?>" class="img-fluid" alt="">
              </div>
            <?php endif; ?>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content d-flex flex-column" data-aos="fade-up" data-aos-delay="100"> 
            <h3><?php echo e($users->nama); ?></h3>
            <p class="text-justify">
                <?php echo $users->alamat; ?>

            </p>
            <a href="<?php echo e($users->link_toko); ?>" class="text-decoration-none btn btn-warning mt-1" style="width: 50%;">Kunjungi Marketplace</a>
          </div>
    </div>

    </div>
  </section><!-- End Team Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\buahsayur-app\resources\views/home/users/index.blade.php ENDPATH**/ ?>