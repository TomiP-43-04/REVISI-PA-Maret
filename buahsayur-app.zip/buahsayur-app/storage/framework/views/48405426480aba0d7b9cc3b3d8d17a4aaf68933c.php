

<?php $__env->startSection('container'); ?>
    <section id="hero" class="d-flex align-items-center">
        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container position-relative" data-aos="zoom-out" data-aos-delay="100">
                <img src="/img/akhi.png" style="max-height: 200px;">
                <img src="/img/ukhti.png" style="max-height: 200px;">
                <h1>TKIT <span>Luqmanul Hakim</span></h1>
                <h2>Rumah Bayi, Kober, dan TKIT Luqmanul Hakim</h2>
                <div class="d-flex">
                    <a href="/home/profiles" class="btn-get-started scrollto">Profil Sekolah</a>
                    <a href="<?php echo e($profile->link_embed); ?>" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Video Sekolah</span></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section><!-- End Hero -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/index.blade.php ENDPATH**/ ?>