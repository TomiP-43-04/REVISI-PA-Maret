

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row my-3">
            <div class="col-lg-8">
                <h4 class="mb-3"><?php echo e($program->title); ?></h4>
                
                <a href="/dashboard/programs" class="btn btn-success"><span data-feather="arrow-left"></span> Semua Program</a>
                <a href="/dashboard/programs/<?php echo e($program->slug); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
                <form action="/dashboard/programs/<?php echo e($program->slug); ?>" method="POST" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus program <?php echo e($program->title); ?>?')"><span data-feather="x-circle"></span> Hapus</button>
                </form>
                <?php if($program->image): ?>
                    <div>
                        <img src="<?php echo e(asset('storage/' . $program->image)); ?>" class="img-fluid mt-3">
                    </div>
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/program-images/' . $image)); ?>" class="img-fluid mt-3">
                <?php endif; ?>
                <article class="my-3">
                    <?php echo $program->body; ?>

                </article>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/programs/show.blade.php ENDPATH**/ ?>